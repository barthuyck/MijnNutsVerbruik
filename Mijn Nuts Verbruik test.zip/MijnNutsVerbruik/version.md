# changelog

2.1.0.1
- initial commit on GitHub

2.2.0.0
- update to android studio 3.6 and corresponding compiler updates 

3.0.0.0
- add extra menu to reload data manual
- add gas to daily plot 

3.1.1.0
- add gas to weekly plot 

3.1.2.0
- add gas to monthly plot 

3.1.3.0
- add gas to yearly plot
 
3.1.4.0
- add gas to weekly plot 

3.2
- add possiblity to switch of visualisation Water or gas 

3.2.1
- changed some typo's

3.2.2.0
- changed some typo's
- correct github link

3.3.0.0
- check for data quality

3.3.0.4
- landscape modus

