# MijnNutsVerbruik

Deze app leest de informatie van een een water (pulsteller, opgeslagen per kwartier) in en geeft deze weer per dag, week, maand en jaar om inzicht te verkrijgen in het jaarverbruik.

![Dagverbruik](screenshot1.png) 

![Weekverbruik](screenshot2.png) 

![Maandverbruik](screenshot3.png) 

![Jaarverbruik](screenshot4.png) 
